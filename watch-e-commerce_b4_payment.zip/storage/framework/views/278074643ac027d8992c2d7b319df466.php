<?php
    $firstImage = $product->images->get(0);
    $secondImage = $product->images->get(1);
?>

<div class="col-6 col-md-4 col-lg-3">
    <div class="product product-11 mt-v3 text-center">
        <figure class="product-media">
            <a href="<?php echo e(route('product.show', $product->id)); ?>">
                <img src="<?php echo e($firstImage ? asset('public/assets/images/demos/demo-2/products/' . $firstImage->path) : asset('no-image.jpg')); ?>"
                     alt="<?php echo e($product->name); ?>" class="product-image">
                <img src="<?php echo e($secondImage ? asset('public/assets/images/demos/demo-2/products/' . $secondImage->path) : asset('no-image.jpg')); ?>"
                     alt="<?php echo e($product->name); ?>" class="product-image-hover">
            </a>
        </figure>
        <div class="product-body">
            <h3 class="product-title">
                <a href="<?php echo e(route('product.show', $product->id)); ?>"><?php echo e($product->name); ?></a>
            </h3>
            <div class="product-price">$<?php echo e($product->price); ?></div>
        </div>
        <div class="product-action">
            <a href="<?php echo e(route('order.add', $product->id)); ?>" class="btn-product btn-cart"><span>Order Now</span></a>
        </div>
    </div>
</div>
<?php /**PATH E:\xampp-8\htdocs\watch-e-commerce\resources\views/web/partials/product-card.blade.php ENDPATH**/ ?>