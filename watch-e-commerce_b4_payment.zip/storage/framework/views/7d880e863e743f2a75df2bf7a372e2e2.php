
<?php $__env->startSection('content'); ?>

<h1>About us </h1>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts2.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp-8\htdocs\watch-e-commerce\resources\views/web/pages/about.blade.php ENDPATH**/ ?>