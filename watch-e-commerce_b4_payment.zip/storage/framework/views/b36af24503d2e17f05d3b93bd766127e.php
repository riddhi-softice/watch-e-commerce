  <header class="header">
    <div class="header-middle sticky-header">
        <div class="container">
            <div class="header-left">
                <button class="mobile-menu-toggler">
                    <span class="sr-only">Toggle mobile menu</span>
                    <i class="icon-bars"></i>
                </button>

                <a href="<?php echo e(url('/')); ?>" class="logo">
                    <img src="<?php echo e(asset('public/assets/images/logo.png')); ?>" alt="Molla Logo" width="105" height="25">
                </a>

                <nav class="main-nav">
                    <ul class="menu sf-arrows">
                        <li class="megamenu-container <?php echo e(Request::is('/') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('/')); ?>" class="goto-demos">Home</a>
                        </li>
                        <li class="<?php echo e(Request::is('more-products') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('more-products')); ?>" class="goto-demos">Shop</a>
                        </li>
                        <li class="<?php echo e(Request::is('orders/index') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('orders/history')); ?>" class="goto-demos">My Orders</a>
                        </li>
                    </ul>
                </nav>

                <!-- <nav class="main-nav">
                    <ul class="menu sf-arrows">
                        <li class="megamenu-container active">
                            <a href="<?php echo e(url('/')); ?>" class="goto-demos">Home</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('more-products')); ?>" class="goto-demos">Shop</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/orders/index')); ?>" class="goto-demos">My Orders</a>
                        </li>
                    </ul>
                </nav> -->
            </div><!-- End .header-left -->

            <div class="header-right">

            <div class="dropdown user-dropdown">
                <?php if(auth()->check()): ?>
                    <a href="<?php echo e(route('user.logout')); ?>">
                        <i class="fa fa-sign-out" aria-hidden="true"></i> Logout
                    </a>
                <?php else: ?>
                    <a href="#signin-modal" data-toggle="modal">
                        <i class="icon-user"></i> Login
                    </a>
                <?php endif; ?>
            </div><!-- End .user-dropdown -->

            </div><!-- End .header-right -->
        </div><!-- End .container -->
    </div><!-- End .header-middle -->
</header><!-- End .header -->
<?php /**PATH E:\xampp-8\htdocs\watch-e-commerce\resources\views/web/layouts2/_header.blade.php ENDPATH**/ ?>