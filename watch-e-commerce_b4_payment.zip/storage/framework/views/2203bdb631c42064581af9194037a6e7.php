
<?php $__env->startSection('content'); ?>

<div class="page-header text-center"
    style="background-image: url('<?php echo e(asset('public/assets/images/page-header-bg.jpg')); ?>');">
    <div class="container">
        <h1 class="page-title">Orders<span>Shop</span></h1>
    </div><!-- End .container -->
</div><!-- End .page-header -->
<nav aria-label="breadcrumb" class="breadcrumb-nav">
    <div class="container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(url('more-products')); ?>">Shop</a></li>
            <li class="breadcrumb-item active" aria-current="page">Orders</li>
        </ol>
    </div><!-- End .container -->
</nav><!-- End .breadcrumb-nav -->

<div class="page-content">
    <div class="container">
        <table class="table table-wishlist table-mobile">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data['order_history']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <tr>
                    <td class="product-col">
                        <div class="product">
                            <figure class="product-media">
                                <a href="<?php echo e(route('product.show', $item->product->id)); ?>">
                                    <img src="<?php echo e($item->product->firstImage->path ? asset('public/assets/images/demos/demo-2/products/' . $item->product->firstImage->path) : asset('no-image.jpg')); ?>"
                                        alt="Product image">
                                </a>
                            </figure>
                            <h3 class="product-title">
                                <a href="<?php echo e(route('product.show', $item->product->id)); ?>"><?php echo e($item->product->name); ?></a>
                            </h3>
                        </div>
                    </td>
                    <td class="price-col"><?php echo e(number_format($item->product->price, 2)); ?></td>
                    <td class="stock-col"><span class="in-stock"><?php echo e($item->status); ?></span></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center">
                        <i class="icon-shopping-cart"></i> You haven’t placed any orders yet.
                        <a href="<?php echo e(route('home')); ?>">Start Shopping</a>
                    </td>
                </tr>
                <?php endif; ?>

            </tbody>
        </table><!-- End .table table-wishlist -->

        <div class="wishlist-share">
            <div class="social-icons social-icons-sm mb-2">
                <label class="social-label">Share on:</label>
                <a href="#" class="social-icon" title="Facebook" target="_blank"><i class="icon-facebook-f"></i></a>
                <a href="#" class="social-icon" title="Twitter" target="_blank"><i class="icon-twitter"></i></a>
                <a href="#" class="social-icon" title="Instagram" target="_blank"><i class="icon-instagram"></i></a>
                <a href="#" class="social-icon" title="Youtube" target="_blank"><i class="icon-youtube"></i></a>
            </div><!-- End .soial-icons -->
        </div><!-- End .wishlist-share -->
    </div><!-- End .container -->
</div><!-- End .page-content -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts2.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp-8\htdocs\watch-e-commerce\resources\views/web/order/order_history.blade.php ENDPATH**/ ?>