@extends('web.layouts2.app')
@section('content')

<h1>terms-and-conditions</h1>

@endsection
@section('javascript')
@endsection