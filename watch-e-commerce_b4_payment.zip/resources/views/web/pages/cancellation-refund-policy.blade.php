@extends('web.layouts2.app')
@section('content')

<h1>cancellation-refund-policy </h1>

@endsection
@section('javascript')
@endsection