@extends('web.layouts2.app')
@section('content')

<h1>contat us </h1>

@endsection
@section('javascript')
@endsection