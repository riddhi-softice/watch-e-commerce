@extends('web.layouts2.app')
@section('content')

<h1>About us </h1>

@endsection
@section('javascript')
@endsection