<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\web\ProductController;
use App\Http\Controllers\web\OrderController;
use App\Http\Controllers\web\CartController;
use App\Http\Controllers\web\RegisterController;
use App\Http\Controllers\web\AccountController;

Route::get('test', function () {
    return view('web.12');
});

Route::get('about', function () {
    return view('web.pages.about');
});
Route::get('terms-and-conditions', function () {
    return view('web.pages.terms-and-conditions');
});
Route::get('shipping-delivery-policy', function () {
    return view('web.pages.shipping-delivery-policy');
});
Route::get('cancellation-refund-policy', function () {
    return view('web.pages.cancellation-refund-policy');
});
Route::get('contact-us', function () {
    return view('web.pages.contact-us');
});

    Route::controller(ProductController::class)->group(function () {

        Route::get('/','home_page')->name('home');
        Route::get('more-products','more_product')->name('product.more');

        Route::get('product/show/{id}','details_page')->name('product.show');
       
    });   

    Route::middleware(['auth'])->group(function () {

        Route::controller(OrderController::class)->group(function () { 
            Route::get('addOrder/{id}','addOrder')->name('order.add');
            Route::post('place/order','placeOrder')->name('order.place');
            
            Route::get('orders/history', 'orderHistory')->name('orders.history');  // order page 
        });

        Route::controller(AccountController::class)->group(function () {

            Route::get('user/dashboard','dashboard')->name('user.dashboard');
            Route::post('update/account','update_account')->name('update.account');

            Route::get('/logout', 'logout')->name('user.logout');
        });
    });

    Route::controller(RegisterController::class)->group(function () {
   
        Route::get('sign-in', function () {
            return view('web.sign-in');
        })->name('sign-in');

        Route::post('/register', 'register')->name('user.register');
        Route::post('/login', 'login')->name('login');
    });