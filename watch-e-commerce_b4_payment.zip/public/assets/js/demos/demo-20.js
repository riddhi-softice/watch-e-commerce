// Demo 20 Js file
$(document).ready(function () {
    'use strict';
});