@extends('web.layouts2.app')
@section('content')

<h1>shipping-delivery-policy </h1>

@endsection
@section('javascript')
@endsection